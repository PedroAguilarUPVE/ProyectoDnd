
package modelos;

public class ORaza {

	int id_Raza;
	String NombreRaza;
	String DescripcionRaza;
	String TamañoRaza;
	int VelocidadRaza;
	int id_EstadisticasRaza;
	int Fuerza;
	int Destreza;
	int Constitucion;
	int Inteligencia;
	int Sabiduria;
	int Carisma;
	
	public int getId_Raza() {
		return id_Raza;
	}
	public void setId_Raza(int id_Raza) {
		this.id_Raza = id_Raza;
	}
	public String getNombreRaza() {
		return NombreRaza;
	}
	public void setNombreRaza(String nombreRaza) {
		NombreRaza = nombreRaza;
	}
	public String getDescripcionRaza() {
		return DescripcionRaza;
	}
	public void setDescripcionRaza(String descripcionRaza) {
		DescripcionRaza = descripcionRaza;
	}
	public String getTamañoRaza() {
		return TamañoRaza;
	}
	public void setTamañoRaza(String tamañoRaza) {
		TamañoRaza = tamañoRaza;
	}
	public int getVelocidadRaza() {
		return VelocidadRaza;
	}
	public void setVelocidadRaza(int velocidadRaza) {
		VelocidadRaza = velocidadRaza;
	}
	public int getId_EstadisticasRaza() {
		return id_EstadisticasRaza;
	}
	public void setId_EstadisticasRaza(int id_EstadisticasRaza) {
		this.id_EstadisticasRaza = id_EstadisticasRaza;
	}
	public int getFuerza() {
		return Fuerza;
	}
	public void setFuerza(int fuerza) {
		Fuerza = fuerza;
	}
	public int getDestreza() {
		return Destreza;
	}
	public void setDestreza(int destreza) {
		Destreza = destreza;
	}
	public int getConstitucion() {
		return Constitucion;
	}
	public void setConstitucion(int constitucion) {
		Constitucion = constitucion;
	}
	public int getInteligencia() {
		return Inteligencia;
	}
	public void setInteligencia(int inteligencia) {
		Inteligencia = inteligencia;
	}
	public int getSabiduria() {
		return Sabiduria;
	}
	public void setSabiduria(int sabiduria) {
		Sabiduria = sabiduria;
	}
	public int getCarisma() {
		return Carisma;
	}
	public void setCarisma(int carisma) {
		Carisma = carisma;
	}
	
}