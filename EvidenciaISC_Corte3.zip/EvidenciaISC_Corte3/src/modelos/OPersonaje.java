package modelos;

public class OPersonaje {

	int id_Personaje;
	String NombrePersonaje;
	int Nivel;
	int id_Clase;
	int id_Subclase;
	int id_Raza;
	int BonusCompetencia;
	int id_EstadisticasPersonaje;
	int Fuerza;
	int Destreza;
	int Constitucion;
	int Inteligencia;
	int Sabiduria;
	int Carisma;
	
	public int getId_Personaje() {
		return id_Personaje;
	}
	public void setId_Personaje(int id_Personaje) {
		this.id_Personaje = id_Personaje;
	}
	public String getNombrePersonaje() {
		return NombrePersonaje;
	}
	public void setNombrePersonaje(String nombrePersonaje) {
		NombrePersonaje = nombrePersonaje;
	}
	public int getNivel() {
		return Nivel;
	}
	public void setNivel(int nivel) {
		Nivel = nivel;
	}
	public int getId_Clase() {
		return id_Clase;
	}
	public void setId_Clase(int id_Clase) {
		this.id_Clase = id_Clase;
	}
	public int getId_Subclase() {
		return id_Subclase;
	}
	public void setId_Subclase(int id_Subclase) {
		this.id_Subclase = id_Subclase;
	}
	public int getId_Raza() {
		return id_Raza;
	}
	public void setId_Raza(int id_Raza) {
		this.id_Raza = id_Raza;
	}
	public int getBonusCompetencia() {
		return BonusCompetencia;
	}
	public void setBonusCompetencia(int bonusCompetencia) {
		BonusCompetencia = bonusCompetencia;
	}
	public int getId_EstadisticasPersonaje() {
		return id_EstadisticasPersonaje;
	}
	public void setId_EstadisticasPersonaje(int id_EstadisticasPersonaje) {
		this.id_EstadisticasPersonaje = id_EstadisticasPersonaje;
	}
	public int getFuerza() {
		return Fuerza;
	}
	public void setFuerza(int fuerza) {
		Fuerza = fuerza;
	}
	public int getDestreza() {
		return Destreza;
	}
	public void setDestreza(int destreza) {
		Destreza = destreza;
	}
	public int getConstitucion() {
		return Constitucion;
	}
	public void setConstitucion(int constitucion) {
		Constitucion = constitucion;
	}
	public int getInteligencia() {
		return Inteligencia;
	}
	public void setInteligencia(int inteligencia) {
		Inteligencia = inteligencia;
	}
	public int getSabiduria() {
		return Sabiduria;
	}
	public void setSabiduria(int sabiduria) {
		Sabiduria = sabiduria;
	}
	public int getCarisma() {
		return Carisma;
	}
	public void setCarisma(int carisma) {
		Carisma = carisma;
	}
	
	


	
}
