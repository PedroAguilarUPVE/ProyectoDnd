/**
 * 
 */
/**
 * 
 */
module EvidenciaISCCorte3 {
	requires java.desktop;
	requires org.apache.commons.math4.core;
	requires PlaceHolder;
	requires java.sql;
}