package modelos;


public class OClase {
	

	private Integer idClase;
	private String nombreClase;
	private String descripcionClase;
	private String tipoClase;
	private Integer DadoDaño;
	
	
	
	public Integer getIdClase() {
		return idClase;
	}
	public void setIdClase(Integer idClase) {
		this.idClase = idClase;
	}
	public String getNombreClase() {
		return nombreClase;
	}
	public void setNombreClase(String nombreClase) {
		this.nombreClase = nombreClase;
	}
	public String getDescripcionClase() {
		return descripcionClase;
	}
	public void setDescripcionClase(String descripcionClase) {
		this.descripcionClase = descripcionClase;
	}
	public String getTipoClase() {
		return tipoClase;
	}
	public void setTipoClase(String tipoClase) {
		this.tipoClase = tipoClase;
	}
	public Integer getDadoDaño() {
		return DadoDaño;
	}
	public void setDadoDaño(Integer dadoDaño) {
		DadoDaño = dadoDaño;
	}

}
