package controladores;


public class Mensajes {
	
	public boolean Validacion;
	public String Mensaje;
	
	public boolean getValidacion() {
		return Validacion;
	}
	public void setValidacion(boolean validacion) {
		Validacion = validacion;
	}
	public String getMensaje() {
		return Mensaje;
	}
	public void setMensaje(String mensaje) {
		Mensaje = mensaje;
	}


}
