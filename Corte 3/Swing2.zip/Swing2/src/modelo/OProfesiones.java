package modelo;

public class OProfesiones {
	
	private int IdProfesion;
	private String Profesion;
	/**
	 * @return the idProfesion
	 */
	public int getIdProfesion() {
		return IdProfesion;
	}
	/**
	 * @param idProfesion the idProfesion to set
	 */
	public void setIdProfesion(int idProfesion) {
		IdProfesion = idProfesion;
	}
	/**
	 * @return the profesion
	 */
	public String getProfesion() {
		return Profesion;
	}
	/**
	 * @param profesion the profesion to set
	 */
	public void setProfesion(String profesion) {
		Profesion = profesion;
	}
	
	

}
