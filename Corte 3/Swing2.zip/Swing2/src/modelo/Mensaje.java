package modelo;

public class Mensaje {
	private boolean Respuesta;
	private String Msj;
	
	
	public boolean getRespuesta() {
		return Respuesta;
	}
	public void setRespuesta(boolean respuesta) {
		Respuesta = respuesta;
	}
	public String getMsj() {
		return Msj;
	}
	public void setMsj(String msj) {
		Msj = msj;
	}
	
	

}
