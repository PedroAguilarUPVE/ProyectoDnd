package vistas;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JSpinner;
/**
 * Clase PanelEstadisticas (Vacio) Componente encargado de contener los controladores de estadisticas de un personaje o raza y poder acceder a sus valores
 */
public class PanelEstadisticas extends JPanel {

	private static final long serialVersionUID = 1L;
	private JSpinner spinnerFue;
	private JSpinner spinnerDes;
	private JSpinner spinnerCon;
	private JSpinner spinnerInt;
	private JSpinner spinnerCar;
	private JSpinner spinnerSab;
	private JLabel lblModFue;
	private JLabel lblModDes;
	private JLabel lblModCon;
	private JLabel lblModInt;
	private JLabel lblModSab;
	private JLabel lblModCar;

	/**
	 * Create the panel.
	 */
	public PanelEstadisticas() {
		setBorder(null);
		setLayout(null);
		
		JPanel panelFuerza = new JPanel();
		panelFuerza.setLayout(null);
		panelFuerza.setBackground(Color.LIGHT_GRAY);
		panelFuerza.setBounds(0, 0, 60, 75);
		add(panelFuerza);
		
		lblModFue = new JLabel("0");
		lblModFue.setHorizontalAlignment(SwingConstants.CENTER);
		lblModFue.setFont(new Font("Sylfaen", Font.PLAIN, 16));
		lblModFue.setBounds(10, 11, 45, 20);
		panelFuerza.add(lblModFue);
		
		JLabel lblFue = new JLabel((String) null);
		lblFue.setVerticalAlignment(SwingConstants.TOP);
		lblFue.setHorizontalAlignment(SwingConstants.CENTER);
		lblFue.setFont(new Font("Sylfaen", Font.PLAIN, 12));
		lblFue.setBounds(0, 59, 57, 14);
		panelFuerza.add(lblFue);
		
		spinnerFue = new JSpinner();
		spinnerFue.setBounds(10, 30, 47, 20);
		panelFuerza.add(spinnerFue);
		
		JPanel panelDestreza = new JPanel();
		panelDestreza.setLayout(null);
		panelDestreza.setBackground(Color.LIGHT_GRAY);
		panelDestreza.setBounds(70, 0, 60, 75);
		add(panelDestreza);
		
		lblModDes = new JLabel("0");
		lblModDes.setHorizontalAlignment(SwingConstants.CENTER);
		lblModDes.setFont(new Font("Sylfaen", Font.PLAIN, 16));
		lblModDes.setBounds(10, 11, 43, 20);
		panelDestreza.add(lblModDes);
		
		JLabel lblDes = new JLabel((String) null);
		lblDes.setVerticalAlignment(SwingConstants.TOP);
		lblDes.setHorizontalAlignment(SwingConstants.CENTER);
		lblDes.setFont(new Font("Sylfaen", Font.PLAIN, 12));
		lblDes.setBounds(0, 59, 57, 14);
		panelDestreza.add(lblDes);
		
		spinnerDes = new JSpinner();
		spinnerDes.setBounds(10, 30, 47, 20);
		panelDestreza.add(spinnerDes);
		
		JPanel panelConstitucion = new JPanel();
		panelConstitucion.setLayout(null);
		panelConstitucion.setBackground(Color.LIGHT_GRAY);
		panelConstitucion.setBounds(140, 0, 60, 75);
		add(panelConstitucion);
		
		lblModCon = new JLabel("0");
		lblModCon.setHorizontalAlignment(SwingConstants.CENTER);
		lblModCon.setFont(new Font("Sylfaen", Font.PLAIN, 16));
		lblModCon.setBounds(10, 11, 43, 20);
		panelConstitucion.add(lblModCon);
		
		JLabel lblCon = new JLabel((String) null);
		lblCon.setVerticalAlignment(SwingConstants.TOP);
		lblCon.setHorizontalAlignment(SwingConstants.CENTER);
		lblCon.setFont(new Font("Sylfaen", Font.PLAIN, 11));
		lblCon.setBounds(0, 59, 63, 14);
		panelConstitucion.add(lblCon);
		
		spinnerCon = new JSpinner();
		spinnerCon.setBounds(10, 30, 47, 20);
		panelConstitucion.add(spinnerCon);
		
		JPanel panelInteligencia = new JPanel();
		panelInteligencia.setLayout(null);
		panelInteligencia.setBackground(Color.LIGHT_GRAY);
		panelInteligencia.setBounds(210, 0, 60, 75);
		add(panelInteligencia);
		
		lblModInt = new JLabel("0");
		lblModInt.setHorizontalAlignment(SwingConstants.CENTER);
		lblModInt.setFont(new Font("Sylfaen", Font.PLAIN, 16));
		lblModInt.setBounds(10, 11, 47, 20);
		panelInteligencia.add(lblModInt);
		
		JLabel lblInt = new JLabel((String) null);
		lblInt.setVerticalAlignment(SwingConstants.TOP);
		lblInt.setHorizontalAlignment(SwingConstants.CENTER);
		lblInt.setFont(new Font("Sylfaen", Font.PLAIN, 12));
		lblInt.setBounds(0, 59, 63, 14);
		panelInteligencia.add(lblInt);
		
		spinnerInt = new JSpinner();
		spinnerInt.setBounds(10, 30, 47, 20);
		panelInteligencia.add(spinnerInt);
		
		JPanel panelSabiduria = new JPanel();
		panelSabiduria.setLayout(null);
		panelSabiduria.setBackground(Color.LIGHT_GRAY);
		panelSabiduria.setBounds(280, 0, 60, 75);
		add(panelSabiduria);
		
		lblModSab = new JLabel("0");
		lblModSab.setHorizontalAlignment(SwingConstants.CENTER);
		lblModSab.setFont(new Font("Sylfaen", Font.PLAIN, 16));
		lblModSab.setBounds(10, 11, 47, 20);
		panelSabiduria.add(lblModSab);
		
		JLabel lblSab = new JLabel((String) null);
		lblSab.setVerticalAlignment(SwingConstants.TOP);
		lblSab.setHorizontalAlignment(SwingConstants.CENTER);
		lblSab.setFont(new Font("Sylfaen", Font.PLAIN, 12));
		lblSab.setBounds(0, 59, 57, 14);
		panelSabiduria.add(lblSab);
		
		spinnerSab = new JSpinner();
		spinnerSab.setBounds(10, 30, 47, 20);
		panelSabiduria.add(spinnerSab);
		
		JPanel panelCarisma = new JPanel();
		panelCarisma.setLayout(null);
		panelCarisma.setBackground(Color.LIGHT_GRAY);
		panelCarisma.setBounds(350, 0, 60, 75);
		add(panelCarisma);
		
		lblModCar = new JLabel("0");
		lblModCar.setHorizontalAlignment(SwingConstants.CENTER);
		lblModCar.setFont(new Font("Sylfaen", Font.PLAIN, 16));
		lblModCar.setBounds(10, 11, 47, 20);
		panelCarisma.add(lblModCar);
		
		JLabel lblCar = new JLabel((String) null);
		lblCar.setVerticalAlignment(SwingConstants.TOP);
		lblCar.setHorizontalAlignment(SwingConstants.CENTER);
		lblCar.setFont(new Font("Sylfaen", Font.PLAIN, 12));
		lblCar.setBounds(0, 59, 57, 14);
		panelCarisma.add(lblCar);
		
		spinnerCar = new JSpinner();
		spinnerCar.setBounds(10, 30, 47, 20);
		panelCarisma.add(spinnerCar);

	}
	
	
}
