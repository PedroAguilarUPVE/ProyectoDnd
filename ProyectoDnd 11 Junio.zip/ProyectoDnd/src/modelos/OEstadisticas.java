package modelos;

public class OEstadisticas {

}
