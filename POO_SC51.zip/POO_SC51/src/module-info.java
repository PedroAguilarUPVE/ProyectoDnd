/**
 * 
 */
/**
 * 
 */
module POO_SC51 {
	requires java.desktop;
	requires PlaceHolder;
	requires org.apache.commons.math4.core;
	requires jcalendar;
}